#!/bin/bash
cat 724450179057-functions.txt | sed -n '/"matches"/,/"locations"/p' | sed -n '/"fixed"/,/"locations"/p' | sed -n '/"High"/,/"locations"/p' | grep -A2 "artifact" | sed 's/.*artifact.*//' >> show.txt
