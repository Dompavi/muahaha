#!/bin/bash
accounts=($(cat ~/tomscript/profiles/$1.file))
fnames=($(grep -B3 "High" ${accounts[@]}-functions.txt | sed -e 's/.*vulnerability.*//' | sed -e 's/.*High.*//' | sed -e  's/.*--.*//' | sed -e '/^$/d' | sed -r '/^\s*$/d'))
fseverity=($(grep "High" ${accounts[@]}-functions.txt | sed 's/"severity"://' | sed 's/,//' | sed 's/"//' | sed 's/"//'
))
fvulnerabilities=($(grep "id" ${accounts[@]}-functions.txt | sed 's/"id"://' | sed 's/,//' | sed 's/"//' | sed 's/"//'))
ffixes=($(grep -A2 "fix" ${accounts[@]}-functions.txt | sed -e 's/.*fix.*//' | sed -e 's/.*versions.*//' | sed -e 's/.*--.*//' | sed 's/"//' | sed 's/"//' | sed -e '/^$/d' | sed -r '/^\s*$/d'))
len=${#fnames[@]}
for (( idx = 0; idx < len; idx++ ));
do
echo "${fnames[idx]},${fseverity[idx]},${fvulnerabilities[idx]}, fixed in version ${ffixes[idx]}" >> ~/tomscript/results/$1/${accounts[@]}-func.txt
done
lnames=($(grep -B3 "High" ${accounts[@]}-layers.txt | sed -e 's/.*vulnerability.*//' | sed -e 's/.*High.*//' | sed -e  's/.*--.*//' | sed -e '/^$/d' | sed -r '/^\s*$/d'))
lseverity=($(grep "High" ${accounts[@]}-layers.txt | sed 's/"severity"://' | sed 's/,//' | sed 's/"//' | sed 's/"//'
))
lvulnerabilities=($(grep "id" ${accounts[@]}-layers.txt | sed 's/"id"://' | sed 's/,//' | sed 's/"//' | sed 's/"//'))
lfixes=($(grep -A2 "fix" ${accounts[@]}-layers.txt | sed -e 's/.*fix.*//' | sed -e 's/.*versions.*//' | sed -e 's/.*--.*//' | sed 's/"//' | sed 's/"//' | sed -e '/^$/d' | sed -r '/^\s*$/d'))
llen=${#names[@]}
for (( idx = 0; idx < len; idx++ ));
do
echo "${lnames[idx]},${lseverity[idx]},${lvulnerabilities[idx]}, fixed in version ${lfixes[idx]}" >> ~/tomscript/results/$1/${accounts[@]}-lay.txt
done

